﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Seminar5.Entities;

namespace Seminar5.DataBase
{
    public static class FakeDataBase
    {
        public static List<Product> Products = new List<Product>();
    }
}
